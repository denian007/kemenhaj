<?php

/**
 * Endpoint autocomplete wilayah untuk pendaftaran.php.
 * Tabel sumber: ta_desa, ta_kec, ta_kab.
 * Menggunakan MySQLi sesuai dengan auth_proses.php
 * Mendukung Cascading Dropdown (Kabupaten -> Kecamatan -> Desa)
 */

declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

// Panggil file koneksi yang sama dengan auth_proses.php
require_once '../config.php';

function respond(array $payload, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$tipe = strtolower(trim((string)($_GET['tipe'] ?? '')));
$q = trim((string)($_GET['q'] ?? ''));
$id_kab = trim((string)($_GET['id_kab'] ?? '')); // Parameter dari Kecamatan
$id_kec = trim((string)($_GET['id_kec'] ?? '')); // Parameter dari Desa

// Validasi tipe wilayah
$allowed_tables = [
    'desa' => 'ta_desa',
    'kecamatan' => 'ta_kec',
    'kabupaten' => 'ta_kab',
];

if (!isset($allowed_tables[$tipe])) {
    respond(['success' => false, 'message' => 'Tipe wilayah tidak valid.', 'data' => []], 400);
}

if (mb_strlen($q) < 2) {
    respond(['success' => true, 'data' => []]);
}

$table = $allowed_tables[$tipe];

// Pastikan koneksi $conn tersedia dari config.php
if (!isset($conn) || !($conn instanceof mysqli)) {
    respond([
        'success' => false,
        'message' => 'Koneksi database gagal atau variabel $conn tidak ditemukan di config.php.',
        'data' => []
    ], 500);
}

try {
    // Deteksi nama kolom yang tepat untuk setiap tabel
    $preferredColumns = [
        'desa' => ['nm_desa', 'nama_desa', 'desa', 'nama', 'nm_kel', 'nama_kelurahan', 'kelurahan', 'uraian'],
        'kecamatan' => ['nm_kec', 'nama_kecamatan', 'kecamatan', 'nama', 'nm_kecamatan', 'uraian'],
        'kabupaten' => ['nm_kab', 'nama_kabupaten', 'kabupaten', 'nama', 'nm_kota', 'nama_kota', 'kab_kota', 'uraian'],
    ];

    // Ambil struktur kolom dari tabel
    $columns = [];
    $result = $conn->query("SHOW COLUMNS FROM `$table`");
    if (!$result) {
        throw new RuntimeException("Tidak dapat membaca struktur tabel $table");
    }
    while ($row = $result->fetch_assoc()) {
        $columns[] = $row['Field'];
    }
    $result->free();

    // 1. Cari kolom nama yang cocok
    $nameColumn = null;
    foreach ($preferredColumns[$tipe] as $candidate) {
        foreach ($columns as $column) {
            if (strtolower((string)$column) === $candidate) {
                $nameColumn = (string)$column;
                break 2;
            }
        }
    }

    if ($nameColumn === null) {
        respond([
            'success' => false,
            'message' => "Kolom nama wilayah tidak dikenali pada tabel {$table}. Kolom tersedia: " . implode(', ', $columns),
            'data' => []
        ], 500);
    }

    // 2. Cari kolom ID (Primary Key) untuk dikembalikan ke frontend
    $idColumn = 'id';
    if (!in_array('id', $columns)) {
        // Fallback jika nama primary key bukan 'id' (misal: id_kab, id_kec)
        foreach ($columns as $col) {
            if (str_starts_with(strtolower($col), 'id_')) {
                $idColumn = $col;
                break;
            }
        }
    }

    // 3. Siapkan Query Dasar
    $sql = "SELECT DISTINCT `$idColumn` AS id, `$nameColumn` AS nama FROM `$table` WHERE `$nameColumn` LIKE ?";
    $params = ['%' . $q . '%'];
    $types = 's';

    // 4. Tambahkan Filter Relasi (Cascading)
    if ($tipe === 'kecamatan' && !empty($id_kab)) {
        // Deteksi nama kolom relasi kabupaten di tabel ta_kec (misal: id_kab, id_kabupaten)
        $relColumn = 'id_kab';
        if (!in_array($relColumn, $columns)) {
            foreach ($columns as $col) {
                if (str_contains(strtolower($col), 'kab')) {
                    $relColumn = $col;
                    break;
                }
            }
        }
        $sql .= " AND `$relColumn` = ?";
        $params[] = $id_kab;
        $types .= 's';
    }

    if ($tipe === 'desa' && !empty($id_kec)) {
        // Deteksi nama kolom relasi kecamatan di tabel ta_desa (misal: id_kec, id_kecamatan)
        $relColumn = 'id_kec';
        if (!in_array($relColumn, $columns)) {
            foreach ($columns as $col) {
                if (str_contains(strtolower($col), 'kec')) {
                    $relColumn = $col;
                    break;
                }
            }
        }
        $sql .= " AND `$relColumn` = ?";
        $params[] = $id_kec;
        $types .= 's';
    }

    $sql .= " ORDER BY `$nameColumn` ASC LIMIT 20";

    // Eksekusi Prepared Statement
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new RuntimeException('Gagal menyiapkan kueri: ' . $conn->error);
    }

    $stmt->bind_param($types, ...$params);
    $stmt->execute();

    // Ambil hasil
    $result = $stmt->get_result();
    $data = [];

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $nama = trim((string)($row['nama'] ?? ''));
            $id = trim((string)($row['id'] ?? ''));
            if ($nama !== '') {
                $data[] = [
                    'id' => $id, // ID ini yang akan disimpan ke hidden input di JS
                    'nama' => $nama
                ];
            }
        }
        $result->free();
    }

    $stmt->close();

    respond(['success' => true, 'data' => $data]);
} catch (Throwable $e) {
    error_log('[api_wilayah] ' . $e->getMessage());
    respond([
        'success' => false,
        'message' => 'Gagal mengambil data wilayah dari database: ' . $e->getMessage(),
        'data' => []
    ], 500);
}
