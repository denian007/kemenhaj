<?php
$page_title = "Dashboard";
$page_subtitle = "Sistem Kelola Surat & Porsi Kementerian Haji Kota Subulussalam";

if (basename($_SERVER['PHP_SELF']) == 'pendaftaran.php') {
    $page_title = "Pendaftaran Porsi Haji";
    $page_subtitle = "Kelola data pendaftaran porsi haji jamaah";
} elseif (basename($_SERVER['PHP_SELF']) == 'layanan_umrah.php') {
    $page_title = "Layanan E-Surat Umrah";
    $page_subtitle = "Verifikasi dan rekomendasi paspor umrah";
}
?>
<div class="topbar">
    <div class="topbar-left">
        <button class="btn-toggle-sidebar" id="btnToggleSidebar">
            <i class="fa-solid fa-bars-staggered"></i>
        </button>
        <div class="topbar-title">
            <h1><?= $page_title ?></h1>
            <p><?= $page_subtitle ?></p>
        </div>
    </div>

    <div class="topbar-actions">
        <div class="digital-clock">
            <div class="time" id="clockTime">00:00:00</div>
            <div class="date" id="clockDate">Memuat...</div>
        </div>

        <button class="icon-btn" id="btnTheme" title="Ganti Tema">
            <i class="fa-solid fa-moon"></i>
        </button>

        <button class="icon-btn" id="btnFullscreen" title="Layar Penuh">
            <i class="fa-solid fa-expand"></i>
        </button>

        
        <div class="user-profile">
            <div class="user-profile-info d-none d-sm-block">
                <strong><?=$_SESSION['nama_lengkap']; ?></strong>
                <span>@s<?=$_SESSION['username']; ?></span>
            </div>
            <div class="avatar-gold" style="border-radius:50%;"><i class="fa-solid fa-user"></i></div>
        </div>
    </div>
</div>