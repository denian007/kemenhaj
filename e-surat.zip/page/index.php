<?php
session_start();
include '../crypt-start.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: ../logout.php");
    exit;
}
// print_r($_SESSION);
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dashboard — Kemenhaj</title>
    <link rel="icon" href="../logo.png" type="image/x-icon">
    <link rel="shortcut icon" href="../logo.png" type="image/x-icon">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
    <!-- Path CSS diperbaiki ke luar folder page -->
    <link rel="stylesheet" href="../assets/style.css" />
</head>

<body>

    <?php include 'sidebar.php'; ?>

    <main class="main-content" id="mainContent">
        <?php include 'topbar.php'; ?>

        <div class="content-wrapper">
            <div class="welcome-banner">
                <div>
                    <div class="badge-banner">
                        <i class="fa-solid fa-star"></i> Sistem Informasi & Manajemen Layanan E-Surat
                    </div>
                    <h2>Selamat Datang, <span>Administrator</span></h2>
                    <p>Panel kontrol terpadu pengawasan pendaftaran porsi haji, verifikasi rekomendasi paspor umrah, dan manajemen tata kelola surat administrasi Kota Subulussalam.</p>
                </div>
                <a href="pendaftaran.php" class="btn-banner">
                    <i class="fa-solid fa-plus"></i> Buat Surat Baru
                </a>
            </div>

            <div class="stat-grid">
                <div class="stat-card">
                    <div>
                        <h4>JEMAAH TERDAFTAR</h4>
                        <h2>1,482</h2>
                        <div class="stat-trend up"><i class="fa-solid fa-arrow-up"></i> +12% bulan ini</div>
                    </div>
                    <div class="stat-icon" style="background: #ecfdf5; color: #059669;">
                        <i class="fa-solid fa-users"></i>
                    </div>
                </div>

                <div class="stat-card">
                    <div>
                        <h4>SURAT REKOMENDASI</h4>
                        <h2>328</h2>
                        <div class="stat-trend up"><i class="fa-solid fa-check"></i> 98% terverifikasi</div>
                    </div>
                    <div class="stat-icon" style="background: #eff6ff; color: #2563eb;">
                        <i class="fa-solid fa-file-signature"></i>
                    </div>
                </div>

                <div class="stat-card">
                    <div>
                        <h4>TRAVEL PPII RESMI</h4>
                        <h2>14</h2>
                        <div class="stat-trend warn"><i class="fa-solid fa-certificate"></i> Berizin Kemenhaj</div>
                    </div>
                    <div class="stat-icon" style="background: #fffbeb; color: #d97706;">
                        <i class="fa-solid fa-plane"></i>
                    </div>
                </div>

                <div class="stat-card">
                    <div>
                        <h4>ANTREAN VERIFIKASI</h4>
                        <h2>9</h2>
                        <div class="stat-trend warn"><i class="fa-solid fa-triangle-exclamation"></i> Perlu diproses</div>
                    </div>
                    <div class="stat-icon" style="background: #fef2f2; color: #dc2626;">
                        <i class="fa-solid fa-clock-rotate-left"></i>
                    </div>
                </div>
            </div>

            <div class="row g-4">
                <div class="col-lg-8">
                    <div class="panel h-100">
                        <div class="panel-head">
                            <div>
                                <h3>Grafik Pendaftaran Porsi Haji & Umrah</h3>
                                <p style="font-size:12px; color:var(--text-muted); margin:4px 0 0 0;">Statistik permohonan di Kota Subulussalam Tahun <?= date('Y') ?></p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div id="chartPendaftaran"></div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="panel h-100">
                        <div class="panel-head">
                            <div>
                                <h3>Akses Pintar Administrasi</h3>
                                <p style="font-size:12px; color:var(--text-muted); margin:4px 0 0 0;">Fitur cepat kelola berkas dan data</p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div class="list-pintar">
                                <a href="layanan_umrah.php" class="item-pintar">
                                    <span><i class="fa-solid fa-stamp text-success me-2"></i> Verifikasi Surat Rekomendasi Umrah</span>
                                    <i class="fa-solid fa-chevron-right text-muted"></i>
                                </a>
                                <a href="pendaftaran.php" class="item-pintar">
                                    <span><i class="fa-solid fa-id-card text-primary me-2"></i> Validasi Pendaftaran Porsi Haji</span>
                                    <i class="fa-solid fa-chevron-right text-muted"></i>
                                </a>
                                <a href="pengawasan_travel.php" class="item-pintar">
                                    <span><i class="fa-solid fa-building-shield text-warning me-2"></i> Cek Legalitas Travel PPII</span>
                                    <i class="fa-solid fa-chevron-right text-muted"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <?php include 'footer.php'; ?>
    </main>

    <script>
        let chartInstance = null;

        function renderCharts(theme) {
            const isDark = theme === 'dark';
            const textColor = isDark ? '#94a3b8' : '#64748b';
            const gridColor = isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)';

            if (chartInstance) chartInstance.destroy();

            const options = {
                series: [{
                    name: 'Haji',
                    data: [30, 45, 38, 52, 48, 65, 72, 58, 63, 78, 85, 92]
                }, {
                    name: 'Umrah',
                    data: [20, 28, 32, 25, 30, 38, 42, 35, 40, 45, 50, 55]
                }],
                chart: {
                    type: 'area',
                    height: 300,
                    toolbar: {
                        show: false
                    },
                    fontFamily: 'Plus Jakarta Sans'
                },
                colors: ['#0a5c43', '#c9a227'],
                stroke: {
                    curve: 'smooth',
                    width: 3
                },
                fill: {
                    type: 'gradient',
                    gradient: {
                        opacityFrom: 0.3,
                        opacityTo: 0.05
                    }
                },
                xaxis: {
                    categories: ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'],
                    labels: {
                        style: {
                            colors: textColor
                        }
                    }
                },
                yaxis: {
                    labels: {
                        style: {
                            colors: textColor
                        }
                    }
                },
                grid: {
                    borderColor: gridColor,
                    strokeDashArray: 4
                },
                dataLabels: {
                    enabled: false
                },
                legend: {
                    position: 'top',
                    horizontalAlign: 'right',
                    labels: {
                        colors: textColor
                    }
                },
                theme: {
                    mode: isDark ? 'dark' : 'light'
                }
            };
            chartInstance = new ApexCharts(document.querySelector("#chartPendaftaran"), options);
            chartInstance.render();
        }

        document.addEventListener('DOMContentLoaded', () => {
            renderCharts(localStorage.getItem('theme') || 'light');
        });
    </script>
</body>

</html>
<?php include '../crypt-start.php'; ?>