<?php
session_start();
include '../crypt-start.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: ../logout.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Pendaftaran Porsi Haji — Kemenhaj</title>
    <link rel="icon" href="../logo.png" type="image/x-icon">
    <link rel="shortcut icon" href="../logo.png" type="image/x-icon">

    <!-- Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />

    <!-- DataTables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css" />

    <!-- Flatpickr -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css" />

    <!-- Select2 -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />

    <!-- DateRangePicker -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker@3.1.0/daterangepicker.css" />

    <!-- Custom Global CSS -->
    <link rel="stylesheet" href="../assets/style.css" />

    <!-- Custom CSS Khusus Halaman Ini -->
    <style>
        body {
            font-size: 13px;
        }

        /* --- FIX DROPDOWN & OVERFLOW --- */
        .table-responsive,
        .dataTables_wrapper,
        .table-custom-container {
            overflow: visible !important;
        }

        /* Pastikan dropdown menu melayang paling atas */
        .dropdown-menu {
            z-index: 99999 !important;
        }

        /* --- STYLING TABEL KUSTOM (BORDERED & HEADER PRIMARY) --- */
        .table-custom-container {
            border: 1px solid #dedede;
            border-radius: 12px;
            background: var(--bg-card);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03);
            padding: 20px;
        }

        .table-custom {
            border-collapse: separate;
            border-spacing: 0;
            width: 100% !important;
            border: 1px solid #dedede;
            margin-bottom: 0 !important;
        }

        .table-custom thead th {
            background-color: var(--primary) !important;
            color: #ffffff !important;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 2px solid #dedede !important;
            border-right: 1px solid #dedede !important;
            border-top: none !important;
            padding: 14px 16px !important;
            font-weight: 700;
            vertical-align: middle;
            white-space: nowrap;
        }

        .table-custom thead th:last-child {
            border-right: none !important;
        }

        .table-custom tbody td {
            padding: 12px 16px !important;
            vertical-align: middle;
            color: var(--text-main);
            border-bottom: 1px solid #dedede !important;
            border-right: 1px solid #dedede !important;
            font-size: 13px;
            font-weight: 500;
            background-color: var(--bg-card);
        }

        .table-custom tbody td:last-child {
            border-right: none !important;
        }

        .table-custom tbody tr:last-child td {
            border-bottom: none !important;
        }

        .table-custom.table-hover tbody tr:hover td {
            background-color: rgba(18, 140, 100, 0.05) !important;
        }


        /* Flatpickr */
        .flatpickr-calendar {
            z-index: 20000 !important;
            border-radius: 12px !important;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2) !important;
            border: 1px solid var(--border-color) !important;
            font-family: inherit;
            font-size: 13px;
        }

        .flatpickr-months .flatpickr-month {
            background: var(--primary) !important;
            color: #fff !important;
            border-radius: 12px 12px 0 0;
            fill: #fff !important;
        }

        .flatpickr-current-month .flatpickr-monthDropdown-months {
            background: var(--primary) !important;
            color: #fff !important;
            font-weight: 700;
        }

        .flatpickr-current-month .flatpickr-monthDropdown-months .flatpickr-monthDropdown-month {
            background-color: var(--bg-card) !important;
            color: var(--text-main) !important;
        }

        .flatpickr-current-month input.cur-year {
            color: #fff !important;
            font-weight: 800;
        }

        .flatpickr-months .flatpickr-prev-month,
        .flatpickr-months .flatpickr-next-month {
            color: #fff !important;
            fill: #fff !important;
        }

        .flatpickr-weekdays {
            background: var(--primary) !important;
        }

        span.flatpickr-weekday {
            background: var(--primary) !important;
            color: rgba(255, 255, 255, 0.8) !important;
            font-weight: 600;
        }

        .flatpickr-day.selected,
        .flatpickr-day.startRange,
        .flatpickr-day.endRange,
        .flatpickr-day.selected:hover {
            background: var(--primary) !important;
            border-color: var(--primary) !important;
        }

        .autocomplete-wrap {
            position: relative;
        }

        .autocomplete-results {
            position: absolute;
            inset: calc(100% + 4px) 0 auto 0;
            z-index: 30000;
            display: none;
            max-height: 230px;
            overflow-y: auto;
            padding: 5px;
            background: var(--bg-card, #fff);
            border: 1px solid var(--border-color, #dbe2ea);
            border-radius: 10px;
            box-shadow: 0 12px 28px rgba(15, 23, 42, .16);
        }

        .autocomplete-item {
            display: block;
            width: 100%;
            border: 0;
            border-radius: 7px;
            padding: 9px 11px;
            text-align: left;
            background: transparent;
            color: var(--text-main, #1f2937);
            font: inherit;
            cursor: pointer;
        }

        .autocomplete-item:hover,
        .autocomplete-item:focus {
            background: rgba(18, 140, 100, .10);
            outline: none;
        }

        .autocomplete-message {
            padding: 9px 11px;
            color: var(--text-muted, #64748b);
            font-size: 12px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 16px;
            margin-bottom: 20px;
        }

        .page-title {
            font-size: 22px;
            font-weight: 800;
            color: var(--text-main);
            margin-bottom: 4px;
            letter-spacing: -0.3px;
        }

        .page-subtitle {
            font-size: 13px;
            color: var(--text-muted);
            margin: 0;
        }

        .btn-tambah {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 700;
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: var(--transition);
            box-shadow: 0 4px 15px rgba(18, 140, 100, 0.3);
        }

        .btn-tambah:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(18, 140, 100, 0.4);
            color: #fff;
        }

        .btn-excel {
            background: linear-gradient(135deg, #1d6f42, #157a45);
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 700;
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: var(--transition);
            box-shadow: 0 4px 15px rgba(29, 111, 66, 0.3);
        }

        .btn-excel:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(29, 111, 66, 0.4);
            color: #fff;
        }

        .badge-status {
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 11.5px;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .badge-terverifikasi {
            background: #ecfdf5;
            color: #047857;
            border: 1px solid #a7f3d0;
        }

        .badge-pending {
            background: #fffbeb;
            color: #b45309;
            border: 1px solid #fde68a;
        }

        .badge-ditolak {
            background: #fef2f2;
            color: #b91c1c;
            border: 1px solid #fecaca;
        }

        [data-theme="dark"] .badge-terverifikasi {
            background: rgba(4, 120, 87, 0.2);
            color: #34d399;
            border-color: rgba(4, 120, 87, 0.3);
        }

        [data-theme="dark"] .badge-pending {
            background: rgba(180, 83, 9, 0.2);
            color: #fbbf24;
            border-color: rgba(180, 83, 9, 0.3);
        }

        [data-theme="dark"] .badge-ditolak {
            background: rgba(185, 28, 28, 0.2);
            color: #f87171;
            border-color: rgba(185, 28, 28, 0.3);
        }

        .action-dropdown .dropdown-toggle {
            background: #3b82f6;
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 6px 12px;
            font-size: 13px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            box-shadow: 0 2px 5px rgba(59, 130, 246, 0.3);
            transition: var(--transition);
        }

        .action-dropdown .dropdown-toggle:hover,
        .action-dropdown .dropdown-toggle:focus,
        .action-dropdown.show .dropdown-toggle {
            background: #2563eb;
            box-shadow: 0 4px 10px rgba(37, 99, 235, 0.4);
            color: #fff;
        }

        .action-dropdown .dropdown-toggle::after {
            display: none;
        }

        .action-dropdown {
            position: relative;
        }

        .action-dropdown .dropdown-menu {
            position: absolute;
            inset: auto 0 auto auto;
            margin-top: 4px;
        }

        .action-dropdown .dropdown-menu.dropdown-menu-up {
            top: auto;
            bottom: 100%;
            margin-top: 0;
            margin-bottom: 4px;
        }

        .action-dropdown .dropdown-menu {
            border-radius: 12px;
            border: 1px solid var(--border-color);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            padding: 8px;
            min-width: 160px;
            background: var(--bg-card);
        }

        .action-dropdown .dropdown-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 14px;
            font-size: 13.5px;
            font-weight: 600;
            color: var(--text-main);
            border-radius: 8px;
            transition: var(--transition);
            cursor: pointer;
        }

        .action-dropdown .dropdown-item i {
            font-size: 15px;
            width: 20px;
            text-align: center;
        }

        .action-dropdown .dropdown-item.edit i {
            color: #3b82f6;
        }

        .action-dropdown .dropdown-item.cetak-pendaftaran i {
            color: #f59e0b;
        }

        .action-dropdown .dropdown-item.cetak-f i {
            color: #10b981;
        }

        .action-dropdown .dropdown-item.delete i {
            color: #ef4444;
        }

        .action-dropdown .dropdown-item:hover.edit {
            color: #3b82f6;
            background: #eff6ff;
        }

        .action-dropdown .dropdown-item:hover.cetak-d {
            color: #f59e0b;
            background: #fffbeb;
        }

        .action-dropdown .dropdown-item:hover.cetak-f {
            color: #10b981;
            background: #ecfdf5;
        }

        .action-dropdown .dropdown-item:hover.delete {
            color: #ef4444;
            background: #fef2f2;
        }

        .action-dropdown .dropdown-divider {
            margin: 6px 0;
            border-color: var(--border-color);
        }

        .modal-content {
            border-radius: 16px;
            border: none;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.15);
            background: var(--bg-card);
        }

        .modal-header {
            border-bottom: 1px solid var(--border-color);
            padding: 20px 24px;
            background: var(--bg-body);
            border-radius: 16px 16px 0 0;
        }

        .modal-title {
            font-weight: 800;
            color: var(--primary-dark);
            font-size: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        [data-theme="dark"] .modal-title {
            color: var(--gold-light);
        }

        .modal-body {
            padding: 24px;
            max-height: 70vh;
            overflow-y: auto;
        }

        .modal-footer {
            border-top: 1px solid var(--border-color);
            padding: 16px 24px;
            background: var(--bg-body);
            border-radius: 0 0 16px 16px;
        }

        .form-label {
            font-size: 12px;
            font-weight: 700;
            color: var(--text-main);
            margin-bottom: 6px;
        }

        .form-control,
        .form-select {
            background: var(--bg-card);
            border: 1.5px solid var(--border-color);
            color: var(--text-main);
            border-radius: 8px;
            padding: 8px 12px;
            font-size: 13px;
            transition: var(--transition);
        }

        .form-control:disabled,
        .form-control[readonly] {
            background-color: var(--bg-body) !important;
            opacity: 0.7;
            cursor: not-allowed;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(18, 140, 100, 0.1);
            color: var(--text-main);
        }

        .section-title {
            font-size: 13px;
            font-weight: 800;
            color: var(--primary);
            border-bottom: 2px dashed var(--border-color);
            padding-bottom: 8px;
            margin-bottom: 16px;
            margin-top: 8px;
        }

        .select2-container--bootstrap-5 .select2-selection {
            background-color: var(--bg-card) !important;
            border: 1.5px solid var(--border-color) !important;
            border-radius: 8px !important;
            min-height: 38px !important;
        }

        .select2-container--bootstrap-5 .select2-selection--single .select2-selection__rendered {
            color: var(--text-main) !important;
            font-size: 13px;
            line-height: 36px;
        }

        .select2-container--bootstrap-5 .select2-dropdown {
            background-color: var(--bg-card) !important;
            border: 1px solid var(--border-color) !important;
            border-radius: 8px !important;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            z-index: 99999 !important;
        }

        .filter-wrapper {
            margin-bottom: 20px;
        }

        .filter-toggle-btn {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            color: var(--text-main);
            padding: 8px 16px;
            border-radius: 8px;
            font-weight: 700;
            font-size: 13px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: var(--transition);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.02);
        }

        .filter-toggle-btn:hover {
            background: var(--bg-body);
        }

        .filter-panel {
            background: var(--bg-body);
            padding: 16px;
            border-radius: 8px;
            margin-top: 12px;
            border: 1px solid var(--border-color);
            display: none;
        }
    </style>
</head>

<body>

    <?php include 'sidebar.php'; ?>

    <main class="main-content" id="mainContent">
        <?php include 'topbar.php'; ?>

        <div class="content-wrapper">
            <!-- Header Halaman -->
            <div class="page-header">
                <div>
                </div>
                <div class="d-flex gap-2 flex-wrap">
                    <button class="filter-toggle-btn" id="btnToggleFilter">
                        <i class="fa-solid fa-filter"></i> Filter
                    </button>
                    <button class="btn-excel" id="btnExportExcel">
                        <i class="fa-solid fa-file-excel"></i> Export Excel
                    </button>
                    <button class="btn-tambah" id="btnTambah">
                        <i class="fa-solid fa-plus-circle"></i> Tambah
                    </button>
                </div>
            </div>

            <!-- Panel Tabel -->
            <div class="panel">
                <div class="panel-body p-4">

                    <!-- FILTER PANEL (Collapse) -->
                    <div class="filter-wrapper">
                        <div class="filter-panel" id="filterPanel">
                            <div class="row g-3 align-items-end">
                                <div class="col-md-4">
                                    <label class="form-label mb-1">Cari Nama / NIK</label>
                                    <input type="text" id="filterSearch" class="form-control form-control-sm" placeholder="Ketik nama atau NIK...">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label mb-1">Filter Status</label>
                                    <select id="filterStatus" class="form-select form-select-sm">
                                        <option value="">Semua Status</option>
                                        <option value="Terverifikasi">Terverifikasi</option>
                                        <option value="Pending">Pending</option>
                                        <option value="Ditolak">Ditolak</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label mb-1">Rentang Tanggal Daftar</label>
                                    <input type="text" id="filterTanggal" class="form-control form-control-sm" placeholder="Pilih rentang tanggal...">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- TABEL DATA -->
                    <div class="table-custom-container">
                        <div class="table-responsive">
                            <table id="tabelPendaftaran" class="table table-custom table-hover w-100">
                                <thead>
                                    <tr>
                                        <th class="align-middle text-center">NO</th>
                                        <th class="align-middle text-center">NO. PORSI</th>
                                        <th class="align-middle text-center">NAMA JAMAAH</th>
                                        <th class="align-middle text-center">TEMPAT, TGL LAHIR</th>
                                        <th class="align-middle text-center">ALAMAT</th>
                                        <th class="align-middle text-center">TGL DAFTAR</th>
                                        <th class="align-middle text-center">STATUS</th>
                                        <th class="align-middle text-center"><i class="fa-solid fa-cogs"></i></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Data diisi oleh JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php include 'footer.php'; ?>
    </main>

    <!-- ================= MODAL FORM TAMBAH / EDIT ================= -->
    <div class="modal fade" id="modalForm" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">
                        <i class="fa-solid fa-file-signature text-primary"></i> Form Pendaftaran Jamaah
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="formPendaftaran">
                    <div class="modal-body">
                        <input type="hidden" id="idJamaah">
                        <div class="section-title"><i class="fa-solid fa-user me-1"></i> Data Pribadi Jamaah</div>
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">No. Porsi <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="noPorsi" required placeholder="Cth: 1446-001">
                            </div>
                            <div class="col-md-8">
                                <label class="form-label">Nama Calon Jamaah Haji <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="nama" required placeholder="Sesuai KTP">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">NIK <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" id="nik" required placeholder="16 digit NIK">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Tempat Lahir <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="tempatLahir" required placeholder="Kota/Kabupaten">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Tanggal Lahir <span class="text-danger">*</span></label>
                                <div class="input-group" id="datetimepickerLahir">
                                    <input type="text" class="form-control bg-white" id="tglLahir" required placeholder="Pilih tanggal..." autocomplete="off">
                                    <span class="input-group-text bg-light" id="iconTglLahir" style="cursor: pointer;">
                                        <i class="fa-solid fa-calendar text-muted"></i>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Usia</label>
                                <input type="text" class="form-control bg-light" id="usia" readonly placeholder="Otomatis">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Jenis Kelamin <span class="text-danger">*</span></label>
                                <select class="form-select select2" id="jenkel" required>
                                    <option value="" disabled selected>Pilih...</option>
                                    <option value="L">Laki-laki</option>
                                    <option value="P">Perempuan</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Pendidikan Terakhir</label>
                                <select class="form-select select2" id="pendidikan">
                                    <option value="" disabled selected>Pilih...</option>
                                    <option value="SD">SD/Sederajat</option>
                                    <option value="SMP">SMP/Sederajat</option>
                                    <option value="SMA">SMA/SMK</option>
                                    <option value="D3">Diploma (D3)</option>
                                    <option value="S1">Sarjana (S1)</option>
                                    <option value="S2">Magister (S2)</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Pekerjaan</label>
                                <input type="text" class="form-control" id="pekerjaan" placeholder="Cth: PNS, Wiraswasta">
                            </div>
                        </div>

                        <div class="section-title mt-4"><i class="fa-solid fa-map-location-dot me-1"></i> Alamat & Kontak</div>
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">No. Telp / WA <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" id="telepon" required placeholder="Cth: 081234...">
                            </div>
                            <div class="col-md-8">
                                <label class="form-label">Alamat Lengkap <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="alamat" required placeholder="Nama jalan, RT/RW, No. Rumah">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Kabupaten / Kota <span class="text-danger">*</span></label>
                                <div class="autocomplete-wrap">
                                    <input type="text" class="form-control" id="kabupaten" placeholder="Pilih Kabupaten dulu..." autocomplete="off" aria-autocomplete="list" aria-expanded="false">
                                    <input type="hidden" id="id_kabupaten">
                                    <div class="autocomplete-results" id="hasilKabupaten" role="listbox"></div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Kecamatan <span class="text-danger">*</span></label>
                                <div class="autocomplete-wrap">
                                    <input type="text" class="form-control" id="kecamatan" placeholder="Pilih Kabupaten dulu..." autocomplete="off" aria-autocomplete="list" aria-expanded="false" disabled>
                                    <input type="hidden" id="id_kecamatan">
                                    <div class="autocomplete-results" id="hasilKecamatan" role="listbox"></div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Desa / Kelurahan <span class="text-danger">*</span></label>
                                <div class="autocomplete-wrap">
                                    <input type="text" class="form-control" id="desa" placeholder="Pilih Kecamatan dulu..." autocomplete="off" aria-autocomplete="list" aria-expanded="false" disabled>
                                    <div class="autocomplete-results" id="hasilDesa" role="listbox"></div>
                                </div>
                            </div>
                        </div>

                        <div class="section-title mt-4"><i class="fa-solid fa-building-columns me-1"></i> Data Pendaftaran & Bank</div>
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">Tahun Pendaftaran <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" id="tahun" required value="<?= date('Y') ?>">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Tanggal Daftar <span class="text-danger">*</span></label>
                                <div class="input-group" id="datetimepickerDaftar">
                                    <input type="text" class="form-control bg-white" id="tglDaftar" required autocomplete="off">
                                    <span class="input-group-text bg-light" id="iconTglDaftar" style="cursor: pointer;">
                                        <i class="fa-solid fa-calendar-check text-muted"></i>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Status Pendaftaran <span class="text-danger">*</span></label>
                                <select class="form-select select2" id="status" required>
                                    <option value="pending">Pending (Menunggu)</option>
                                    <option value="terverifikasi">Terverifikasi</option>
                                    <option value="ditolak">Ditolak</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Bank <span class="text-danger">*</span></label>
                                <select class="form-select select2" id="bank" required>
                                    <option value="" disabled selected>Pilih Bank...</option>
                                    <option value="BSI">Bank Syariah Indonesia (BSI)</option>
                                    <option value="Mandiri">Bank Mandiri</option>
                                    <option value="BRI">Bank BRI</option>
                                    <option value="BNI">Bank BNI</option>
                                    <option value="Muamalat">Bank Muamalat</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">No. Rekening <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" id="noRek" required placeholder="Nomor rekening">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">No. Validasi <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="noValidasi" required placeholder="Nomor validasi bank">
                            </div>
                        </div>
                        <input type="hidden" id="timeStamp" value="<?= date('Y-m-d H:i:s') ?>">
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal" style="border: 1.5px solid var(--border-color); font-weight: 600; font-size: 13px;">Batal</button>
                        <button type="submit" class="btn btn-primary" style="background: var(--primary); border: none; font-weight: 700; padding: 8px 24px; font-size: 13px;">
                            <i class="fa-solid fa-floppy-disk me-1"></i> Simpan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- ================= MODAL LIHAT DETAIL ================= -->
    <div class="modal fade" id="modalDetail" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title"><i class="fa-solid fa-id-badge me-2 text-primary"></i> Detail Data Jamaah</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body pt-3">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <small class="text-muted fw-bold d-block">No. Porsi</small>
                            <span id="detPorsi" class="fw-bold fs-6 text-primary"></span>
                        </div>
                        <div class="col-md-6 mb-3">
                            <small class="text-muted fw-bold d-block">Nama Lengkap</small>
                            <span id="detNama" class="fw-bold fs-6"></span>
                        </div>
                        <div class="col-md-6 mb-3">
                            <small class="text-muted fw-bold d-block">NIK</small>
                            <span id="detNik"></span>
                        </div>
                        <div class="col-md-6 mb-3">
                            <small class="text-muted fw-bold d-block">Layanan</small>
                            <span id="detLayanan"></span>
                        </div>
                        <div class="col-md-6 mb-3">
                            <small class="text-muted fw-bold d-block">Tanggal Daftar</small>
                            <span id="detTgl"></span>
                        </div>
                        <div class="col-md-6 mb-3">
                            <small class="text-muted fw-bold d-block">Status</small>
                            <span id="detStatus"></span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-primary w-100" data-bs-dismiss="modal" style="background: var(--primary); border: none; font-weight: 700; font-size: 13px;">Tutup Detail</button>
                </div>
            </div>
        </div>
    </div>

    <!-- ================= SCRIPTS ================= -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.4/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.4/locale/id.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/id.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/daterangepicker@3.1.0/daterangepicker.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

    <script>
        $(document).ready(function() {

            // Toggle Filter Panel
            $('#btnToggleFilter').click(function() {
                $('#filterPanel').slideToggle(200);
            });

            // ==========================================
            // FITUR DEPENDENSI WILAYAH
            // ==========================================
            function setupWilayahAutocomplete(config) {
                const $input = $(config.input);
                const $results = $(config.results);
                const $hiddenId = config.hiddenId ? $(config.hiddenId) : null;
                let timer = null;
                let activeIndex = -1;

                function closeResults() {
                    $results.hide().empty();
                    $input.attr('aria-expanded', 'false');
                    activeIndex = -1;
                }

                function showMessage(message) {
                    $results.html($('<div>', {
                        class: 'autocomplete-message',
                        text: message
                    })).show();
                    $input.attr('aria-expanded', 'true');
                }

                $input.on('input', function() {
                    const keyword = this.value.trim();
                    clearTimeout(timer);
                    if ($hiddenId) $hiddenId.val('');
                    if (keyword.length < 2) {
                        closeResults();
                        return;
                    }
                    if (config.parentId && !$(config.parentId).val()) {
                        showMessage('Harap pilih ' + config.parentLabel + ' terlebih dahulu.');
                        return;
                    }

                    timer = setTimeout(function() {
                        showMessage('Memuat data...');
                        let reqData = {
                            tipe: config.tipe,
                            q: keyword
                        };
                        if (config.parentId) {
                            reqData[config.parentParam] = $(config.parentId).val();
                        }

                        $.ajax({
                            url: '../api/api_wilayah.php',
                            method: 'GET',
                            dataType: 'json',
                            data: reqData
                        }).done(function(response) {
                            $results.empty();
                            if (!response || response.success !== true || !Array.isArray(response.data)) {
                                showMessage((response && response.message) || 'Data tidak dapat dimuat.');
                                return;
                            }
                            if (!response.data.length) {
                                showMessage('Data tidak ditemukan.');
                                return;
                            }
                            response.data.forEach(function(item) {
                                const $button = $('<button>', {
                                    type: 'button',
                                    class: 'autocomplete-item',
                                    role: 'option',
                                    text: item.nama
                                });
                                $button.on('mousedown', function(e) {
                                    e.preventDefault();
                                    $input.val(item.nama).trigger('change');
                                    if ($hiddenId) $hiddenId.val(item.id);
                                    if (config.onSelect) config.onSelect(item);
                                    closeResults();
                                });
                                $results.append($button);
                            });
                            $results.show();
                            $input.attr('aria-expanded', 'true');
                        }).fail(function(xhr, status) {
                            if (status === 'abort') return;
                            showMessage('Gagal menghubungi backend.');
                        });
                    }, 250);
                });

                $input.on('keydown', function(e) {
                    const $items = $results.find('.autocomplete-item');
                    if (!$items.length || !$results.is(':visible')) return;
                    if (e.key === 'ArrowDown') {
                        e.preventDefault();
                        activeIndex = Math.min(activeIndex + 1, $items.length - 1);
                        $items.removeClass('active').eq(activeIndex).addClass('active').trigger('focus');
                    } else if (e.key === 'ArrowUp') {
                        e.preventDefault();
                        activeIndex = Math.max(activeIndex - 1, 0);
                        $items.removeClass('active').eq(activeIndex).addClass('active').trigger('focus');
                    } else if (e.key === 'Escape') closeResults();
                    else if (e.key === 'Enter' && activeIndex >= 0) {
                        e.preventDefault();
                        $items.eq(activeIndex).trigger('mousedown');
                    }
                });

                $(document).on('click', function(e) {
                    if (!$(e.target).closest(config.input + ', ' + config.results).length) closeResults();
                });
            }

            setupWilayahAutocomplete({
                input: '#kabupaten',
                results: '#hasilKabupaten',
                hiddenId: '#id_kabupaten',
                tipe: 'kabupaten',
                onSelect: function(item) {
                    $('#kecamatan').prop('disabled', false).attr('placeholder', 'Ketik nama kecamatan...').val('');
                    $('#id_kecamatan').val('');
                    $('#desa').prop('disabled', true).attr('placeholder', 'Pilih Kecamatan dulu...').val('');
                }
            });
            setupWilayahAutocomplete({
                input: '#kecamatan',
                results: '#hasilKecamatan',
                hiddenId: '#id_kecamatan',
                tipe: 'kecamatan',
                parentId: '#id_kabupaten',
                parentParam: 'id_kab',
                parentLabel: 'Kabupaten',
                onSelect: function(item) {
                    $('#desa').prop('disabled', false).attr('placeholder', 'Ketik nama desa...').val('');
                }
            });
            setupWilayahAutocomplete({
                input: '#desa',
                results: '#hasilDesa',
                tipe: 'desa',
                parentId: '#id_kecamatan',
                parentParam: 'id_kec',
                parentLabel: 'Kecamatan'
            });


            // ==========================================
            // DATATABLES CONFIGURATION (PERBAIKAN HEADER & DROPDOWN)
            // ==========================================
            var table = $('#tabelPendaftaran').DataTable({
                processing: true,
                serverSide: false,
                paging: false,
                ordering: false,
                info: false,
                scrollY: 'calc(100vh - 400px)',
                scrollCollapse: true,
                ajax: {
                    url: '../api/get_pendaftaran.php',
                    dataSrc: 'data'
                },
                columns: [{
                        data: null,
                        searchable: false,
                        className: 'text-center',
                        render: function(data, type, row, meta) {
                            return meta.row + 1;
                        }
                    },
                    {
                        data: 'no_porsi'
                    },
                    {
                        data: 'nama',
                        render: function(data, type, row) {
                            return `<span class="fw-bold text-primary-dark">${row.nama}<br>${row.nik}</span>`;
                        }
                    },
                    {
                        data: 'tempat_lahir',
                        render: function(data, type, row) {
                            return `<span class="fw-bold text-primary-dark">${row.tempat_lahir}, ${row.tgl_lahir} ${row.bulan_lahir} ${row.tahun_lahir}</span>`;
                        }
                    },
                    {
                        data: 'nik',
                        render: function(data, type, row) {
                            return `<span class="fw-bold text-primary-dark">${row.alamat}, Desa ${row.desa} Kec. ${row.kecamatan} ${row.kabupaten}</span>`;
                        }
                    },
                    {
                        data: 'tgl_daftar',
                        render: function(data) {
                            return data ? moment(data).format('DD MMM YYYY') : '-';
                        }
                    },
                    {
                        data: 'status',
                        render: function(data) {
                            if (data === 'terverifikasi') return '<span class="badge-status badge-terverifikasi"><i class="fa-solid fa-check-circle"></i> Terverifikasi</span>';
                            if (data === 'pending') return '<span class="badge-status badge-pending"><i class="fa-solid fa-clock"></i> Pending</span>';
                            return '<span class="badge-status badge-ditolak"><i class="fa-solid fa-times-circle"></i> Ditolak</span>';
                        }
                    },
                    {
                        data: 'uuid',
                        className: 'text-center',
                        render: function(data) {
                            var uuid = data || '';
                            return `
                            <div class="dropdown action-dropdown">
                                <button class="btn btn-sm btn-primary dropdown-toggle btn-action-toggle" type="button" aria-haspopup="true" aria-expanded="false" aria-label="Buka menu aksi">
                                    <i class="fa-solid fa-list-ul"></i> <i class="fa-solid fa-caret-down ms-1"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end shadow">
                                    <li><a class="dropdown-item edit" href="javascript:void(0)" data-uuid="${uuid}"><i class="fa-solid fa-pen-to-square me-2"></i> Edit</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item cetak-pendaftaran" href="javascript:void(0)" data-uuid="${uuid}"><i class="fa-solid fa-print me-2"></i> Cetak</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item delete" href="javascript:void(0)" data-uuid="${uuid}"><i class="fa-solid fa-trash-can me-2"></i> Hapus</a></li>
                                </ul>
                            </div>`;
                        }
                    }
                ]
            });

            // ==========================================
            // EXPORT DATA TO EXCEL (PRESISI SESUAI GAMBAR)
            // ==========================================
            $('#btnExportExcel').click(function() {
                var $btn = $(this);
                var originalText = $btn.html();

                $btn.html('<i class="fa-solid fa-spinner fa-spin me-1"></i> Memuat Data...').prop('disabled', true);

                function processExport() {
                    $.ajax({
                        url: '../api/get_pendaftaran.php',
                        type: 'GET',
                        dataType: 'json',
                        success: function(response) {
                            $btn.html(originalText).prop('disabled', false);

                            if (!response || !Array.isArray(response.data) || response.data.length === 0) {
                                Swal.fire({
                                    icon: 'warning',
                                    title: 'Data Kosong',
                                    text: 'Tidak ada data pendaftaran untuk di-export.',
                                    confirmButtonColor: '#0f2c59'
                                });
                                return;
                            }

                            var XLSX_ENGINE = window.XLSX;
                            var wb = XLSX_ENGINE.utils.book_new();

                            // 1. Header Sesuai Gambar
                            var headers = [
                                "NO", "NO. PORSI", "NAMA JAMAAH", "NIK", "TEMPAT LAHIR",
                                "TANGGAL LAHIR", "USIA", "JENIS KELAMIN", "PENDIDIKAN", "PEKERJAAN",
                                "NO. TELP/WA", "ALAMAT", "DESA/KELURAHAN", "KECAMATAN", "KABUPATEN/KOTA",
                                "TAHUN DAFTAR", "TANGGAL DAFTAR", "BANK", "NO. REKENING", "NO. VALIDASI", "STATUS"
                            ];

                            var matrixData = [headers];

                            response.data.forEach(function(row, index) {
                                var namaClean = (row.nama || '').replace(/<[^>]*>?/gm, '');
                                var tglLahirFormatted = row.tgl_lahir && row.bulan_lahir && row.tahun_lahir ?
                                    String(row.tgl_lahir).padStart(2, '0') + ' ' + row.bulan_lahir + ' ' + row.tahun_lahir :
                                    '-';
                                var statusText = row.status === 'terverifikasi' ?
                                    'Terverifikasi' :
                                    (row.status === 'pending' ? 'Pending' : 'Ditolak');

                                matrixData.push([
                                    index + 1,
                                    String(row.no_porsi || '-'),
                                    namaClean,
                                    String(row.nik || '-'),
                                    row.tempat_lahir || '-',
                                    tglLahirFormatted,
                                    (row.usia || '-') + ' Tahun',
                                    row.jenis_kelamin || '-',
                                    row.pendidikan || '-',
                                    row.pekerjaan || '-',
                                    String(row.hp || '-'),
                                    row.alamat || '-',
                                    row.desa || '-',
                                    row.kecamatan || '-',
                                    row.kabupaten || '-',
                                    String(row.tahun || '-'),
                                    row.tgl_daftar ? moment(row.tgl_daftar).format('DD MMM YYYY') : '-',
                                    row.bank || '-',
                                    String(row.no_rek || '-'),
                                    String(row.no_validasi || '-'),
                                    statusText
                                ]);
                            });

                            // 2. Buat Sheet
                            var ws = XLSX_ENGINE.utils.aoa_to_sheet(matrixData);
                            var range = XLSX_ENGINE.utils.decode_range(ws['!ref']);

                            // Border Tipis Hitam/Abu untuk Setiap Sel
                            var borderThin = {
                                top: {
                                    style: "thin",
                                    color: {
                                        rgb: "000000"
                                    }
                                },
                                bottom: {
                                    style: "thin",
                                    color: {
                                        rgb: "000000"
                                    }
                                },
                                left: {
                                    style: "thin",
                                    color: {
                                        rgb: "000000"
                                    }
                                },
                                right: {
                                    style: "thin",
                                    color: {
                                        rgb: "000000"
                                    }
                                }
                            };

                            // 3. Styling Seluruh Sel
                            for (var R = range.s.r; R <= range.e.r; ++R) {
                                for (var C = range.s.c; C <= range.e.c; ++C) {
                                    var cell_ref = XLSX_ENGINE.utils.encode_cell({
                                        r: R,
                                        c: C
                                    });
                                    if (!ws[cell_ref]) continue;

                                    // Pastikan NIK, Rekening, HP, Porsi disimpan sebagai Teks Murni (s) tanpa tanda petik
                                    if ([1, 3, 10, 18, 19].indexOf(C) !== -1 && R > 0) {
                                        ws[cell_ref].t = 's';
                                    }

                                    if (R === 0) {
                                        // Header: Dark Navy Blue (#0F2C59), Teks Putih Bold, Center
                                        ws[cell_ref].s = {
                                            fill: {
                                                fgColor: {
                                                    rgb: "0F2C59"
                                                }
                                            },
                                            font: {
                                                name: "Segoe UI",
                                                sz: 10,
                                                bold: true,
                                                color: {
                                                    rgb: "FFFFFF"
                                                }
                                            },
                                            alignment: {
                                                horizontal: "center",
                                                vertical: "center",
                                                wrapText: true
                                            },
                                            border: borderThin
                                        };
                                    } else {
                                        // Data Body: Latar Putih, Border Hitam, Posisi Kiri/Tengah Sesuai Kolom
                                        var alignHoriz = (C === 0 || C === 1 || C === 6 || C === 7 || C === 15 || C === 16) ? "center" : "left";

                                        ws[cell_ref].s = {
                                            fill: {
                                                fgColor: {
                                                    rgb: "FFFFFF"
                                                }
                                            },
                                            font: {
                                                name: "Segoe UI",
                                                sz: 10,
                                                color: {
                                                    rgb: "000000"
                                                }
                                            },
                                            alignment: {
                                                horizontal: alignHoriz,
                                                vertical: "center"
                                            },
                                            border: borderThin
                                        };
                                    }
                                }
                            }

                            // 4. Tinggi Baris & Lebar Kolom
                            ws['!rows'] = [{
                                hpt: 26
                            }];
                            for (var r = 1; r <= range.e.r; r++) {
                                ws['!rows'].push({
                                    hpt: 20
                                });
                            }

                            ws['!cols'] = [{
                                    wch: 6
                                }, // NO
                                {
                                    wch: 16
                                }, // NO. PORSI
                                {
                                    wch: 25
                                }, // NAMA JAMAAH
                                {
                                    wch: 22
                                }, // NIK
                                {
                                    wch: 18
                                }, // TEMPAT LAHIR
                                {
                                    wch: 18
                                }, // TANGGAL LAHIR
                                {
                                    wch: 12
                                }, // USIA
                                {
                                    wch: 15
                                }, // JENIS KELAMIN
                                {
                                    wch: 14
                                }, // PENDIDIKAN
                                {
                                    wch: 16
                                }, // PEKERJAAN
                                {
                                    wch: 16
                                }, // NO. TELP/WA
                                {
                                    wch: 28
                                }, // ALAMAT
                                {
                                    wch: 20
                                }, // DESA
                                {
                                    wch: 20
                                }, // KECAMATAN
                                {
                                    wch: 22
                                }, // KABUPATEN
                                {
                                    wch: 15
                                }, // TAHUN
                                {
                                    wch: 16
                                }, // TGL DAFTAR
                                {
                                    wch: 15
                                }, // BANK
                                {
                                    wch: 20
                                }, // NO. REKENING
                                {
                                    wch: 28
                                }, // NO. VALIDASI
                                {
                                    wch: 16
                                } // STATUS
                            ];

                            // 5. Unduh File Excel
                            XLSX_ENGINE.utils.book_append_sheet(wb, ws, "Data Pendaftaran");
                            var fileName = "Data_Pendaftaran_Haji_" + moment().format('YYYYMMDD_HHmmss') + ".xlsx";
                            XLSX_ENGINE.writeFile(wb, fileName);

                            Swal.fire({
                                icon: 'success',
                                title: 'Export Berhasil!',
                                text: 'Data pendaftaran berhasil diunduh.',
                                confirmButtonColor: '#0f2c59',
                                timer: 2000,
                                showConfirmButton: false
                            });
                        },
                        error: function(xhr, status, error) {
                            $btn.html(originalText).prop('disabled', false);
                            Swal.fire({
                                icon: 'error',
                                title: 'Gagal Export',
                                text: 'Terjadi kesalahan saat mengambil data dari server.',
                                confirmButtonColor: '#dc2626'
                            });
                        }
                    });
                }

                // Panggil Engine xlsx-js-style untuk Merender Warna & Border Header
                if (typeof XLSX !== 'undefined' && XLSX.version) {
                    processExport();
                } else {
                    $.getScript('https://cdn.jsdelivr.net/npm/xlsx-js-style@1.2.0/dist/xlsx.bundle.js')
                        .done(function() {
                            processExport();
                        })
                        .fail(function() {
                            processExport();
                        });
                }
            });

            // ==========================================
            // FILTER KUSTOM
            // ==========================================
            $('#filterSearch').on('keyup', function() {
                table.columns([2, 3]).search(this.value).draw();
            });
            $('#filterStatus').on('change', function() {
                table.column(5).search(this.value.toLowerCase()).draw();
            });

            $('#filterTanggal').daterangepicker({
                autoUpdateInput: false,
                locale: {
                    cancelLabel: 'Clear',
                    format: 'DD MMM YYYY'
                }
            });
            $('#filterTanggal').on('apply.daterangepicker', function(ev, picker) {
                $(this).val(picker.startDate.format('DD MMM YYYY') + ' - ' + picker.endDate.format('DD MMM YYYY'));
                $.fn.dataTable.ext.search.push(function(settings, data) {
                    var min = picker.startDate,
                        max = picker.endDate;
                    var date = moment(data[4], "DD MMM YYYY");
                    return ((min == null && max == null) || (min == null && date <= max) || (min <= date && max == null) || (min <= date && date <= max));
                });
                table.draw();
            });
            $('#filterTanggal').on('cancel.daterangepicker', function() {
                $(this).val('');
                $.fn.dataTable.ext.search.pop();
                table.draw();
            });

            // ==========================================
            // DROPDOWN AKSI (delegasi; aman untuk redraw DataTables)
            // ==========================================
            function closeActionDropdowns(exceptWrapper) {
                $('#tabelPendaftaran .action-dropdown.show').each(function() {
                    if (exceptWrapper && this === exceptWrapper) return;
                    $(this).removeClass('show')
                        .children('.dropdown-menu').removeClass('show');
                    $(this).children('.btn-action-toggle').attr('aria-expanded', 'false');
                });
            }

            $('#tabelPendaftaran tbody').on('click', '.btn-action-toggle', function(e) {
                e.preventDefault();
                e.stopPropagation();

                const wrapper = $(this).closest('.action-dropdown')[0];
                const menu = $(wrapper).children('.dropdown-menu')[0];
                const willOpen = !$(wrapper).hasClass('show');

                closeActionDropdowns(wrapper);

                if (willOpen) {
                    $(wrapper).addClass('show');
                    $(menu).addClass('show');
                    $(this).attr('aria-expanded', 'true');

                    // Keep the menu above table content and within the viewport.
                    const rect = this.getBoundingClientRect();
                    const menuHeight = menu.scrollHeight || 220;
                    if (window.innerHeight - rect.bottom < menuHeight && rect.top > menuHeight) {
                        $(menu).addClass('dropdown-menu-up');
                    } else {
                        $(menu).removeClass('dropdown-menu-up');
                    }
                } else {
                    $(wrapper).removeClass('show');
                    $(menu).removeClass('show dropdown-menu-up');
                    $(this).attr('aria-expanded', 'false');
                }
            });

            $(document).on('click.actionDropdown', function(e) {
                if (!$(e.target).closest('#tabelPendaftaran .action-dropdown').length) {
                    closeActionDropdowns();
                }
            });

            $('#tabelPendaftaran tbody').on('click', '.action-dropdown .dropdown-item', function() {
                closeActionDropdowns();
            });

            // Pastikan menu ditutup saat tabel digambar ulang atau halaman diubah.
            table.on('draw.dt', function() {
                closeActionDropdowns();
            });

            // ==========================================
            // CRUD ACTIONS (Event Delegation)
            // ==========================================
            // ==========================================
            // HANDLER TOMBOL EDIT (.edit)
            // ==========================================
            $('#tabelPendaftaran tbody').on('click', '.edit', function(e) {
                e.preventDefault();

                var uuid = $(this).data('uuid');
                if (!uuid) {
                    Swal.fire('Error', 'UUID data tidak ditemukan.', 'error');
                    return;
                }

                // Indikator Loading
                Swal.fire({
                    title: 'Memuat Data...',
                    text: 'Mohon tunggu sebentar',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                // Ambil Data Detail dari Backend API
                $.ajax({
                    url: '../api/get_detail_pendaftaran.php',
                    type: 'GET',
                    dataType: 'json',
                    data: {
                        uuid: uuid
                    },
                    success: function(response) {
                        Swal.close();

                        if (response && response.status === true && response.data) {
                            var d = response.data;

                            // 1. Ubah Judul Modal
                            $('#modalTitle').html('<i class="fa-solid fa-pen-to-square text-primary"></i> Edit Data Pendaftaran Jamaah');

                            // 2. Isi Input Hidden & Utama
                            $('#idJamaah').val(d.uuid || d.id || '');
                            $('#noPorsi').val(d.no_porsi || '');
                            $('#nama').val(d.nama || '');
                            $('#nik').val(d.nik || '');
                            $('#tempatLahir').val(d.tempat_lahir || '');
                            $('#pekerjaan').val(d.pekerjaan || '');
                            $('#telepon').val(d.telepon || '');
                            $('#alamat').val(d.alamat || '');
                            $('#tahun').val(d.tahun || new Date().getFullYear());
                            $('#noRek').val(d.no_rek || '');
                            $('#noValidasi').val(d.no_validasi || '');

                            // 3. Set Tanggal Lahir & Hitung Usia (Flatpickr)
                            if (d.tgl_lahir) {
                                var tglLahirFormatted = moment(d.tgl_lahir).format('DD MMMM YYYY');
                                pickerLahir.setDate(d.tgl_lahir, true);
                                $('#usia').val((d.usia ? d.usia : moment().diff(moment(d.tgl_lahir), 'years')) + ' Tahun');
                            } else {
                                pickerLahir.clear();
                                $('#usia').val('');
                            }

                            // 4. Set Tanggal Daftar (Flatpickr)
                            if (d.tgl_daftar) {
                                pickerDaftar.setDate(d.tgl_daftar, true);
                            } else {
                                pickerDaftar.setDate(new Date(), true);
                            }

                            // 5. Set Select2 Dropdown
                            $('#jenkel').val(d.jenkel || '').trigger('change');
                            $('#pendidikan').val(d.pendidikan || '').trigger('change');
                            $('#status').val(d.status || 'pending').trigger('change');
                            $('#bank').val(d.bank || '').trigger('change');

                            // 6. Set Field Wilayah (Kabupaten, Kecamatan, Desa)
                            $('#id_kabupaten').val(d.id_kabupaten || '');
                            $('#kabupaten').val(d.kabupaten || '');

                            $('#id_kecamatan').val(d.id_kecamatan || '');
                            $('#kecamatan').val(d.kecamatan || '').prop('disabled', !d.id_kabupaten);

                            $('#desa').val(d.desa || '').prop('disabled', !d.id_kecamatan);

                            // 7. Tampilkan Modal Form
                            bootstrap.Modal.getOrCreateInstance(document.getElementById('modalForm')).show();
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Gagal Memuat Data',
                                text: response.message || 'Data jamaah tidak ditemukan.',
                                confirmButtonColor: '#dc2626'
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error edit:', error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Kesalahan Server',
                            text: 'Gagal menghubungi server untuk mengambil detail data.',
                            confirmButtonColor: '#dc2626'
                        });
                    }
                });
            });

            // ==========================================
            // HANDLER TOMBOL CETAK BUKTI PENDAFTARAN
            // ==========================================
            $('#tabelPendaftaran tbody').on('click', '.cetak-pendaftaran', function(e) {
                e.preventDefault();

                // Ambil data UUID dari tombol
                var uuid = $(this).data('uuid');

                if (!uuid) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal Mencetak',
                        text: 'Identifier (UUID) data pendaftaran tidak ditemukan.',
                        confirmButtonColor: '#dc2626'
                    });
                    return;
                }

                // Buka file cetak-pendaftaran.php di tab baru
                var urlCetak = 'cetak-pendaftaran.php?uuid=' + encodeURIComponent(uuid);
                window.open(urlCetak, '_blank');
            });


            // ==========================================
            // HANDLER TOMBOL HAPUS (.delete)
            // ==========================================
            $('#tabelPendaftaran tbody').on('click', '.delete', function(e) {
                e.preventDefault();

                // Ambil UUID dari atribut data-uuid tombol
                var uuid = $(this).data('uuid');

                // Ambil data baris dari DataTables untuk menampilkan nama jamaah
                var $tr = $(this).closest('tr');
                var rowData = table.row($tr).data();
                var namaJamaah = rowData && rowData.nama ? rowData.nama : 'Jamaah';

                // Tampilkan konfirmasi SweetAlert2
                Swal.fire({
                    title: 'Hapus Data Jamaah?',
                    html: `Apakah Anda yakin ingin menghapus data jamaah <b>${namaJamaah}</b>? Data yang dihapus tidak dapat dikembalikan.`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#dc2626',
                    cancelButtonColor: '#64748b',
                    confirmButtonText: '<i class="fa-solid fa-trash-can me-1"></i> Ya, Hapus!',
                    cancelButtonText: 'Batal',
                    reverseButtons: true
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Tampilkan loading saat proses hapus berjalan
                        Swal.fire({
                            title: 'Menghapus Data...',
                            text: 'Mohon tunggu sebentar',
                            allowOutsideClick: false,
                            didOpen: () => {
                                Swal.showLoading();
                            }
                        });

                        // Kirim permintaan hapus ke backend API
                        $.ajax({
                            url: '../api/hapus_pendaftaran.php', // Sesuaikan dengan path file API hapus Anda
                            type: 'POST',
                            dataType: 'json',
                            data: {
                                uuid: uuid
                            },
                            success: function(response) {
                                if (response && (response.status === true || response.success === true)) {
                                    Swal.fire({
                                        icon: 'success',
                                        title: 'Berhasil Dihapus!',
                                        text: response.message || 'Data jamaah telah berhasil dihapus.',
                                        confirmButtonColor: '#0a5c43',
                                        timer: 2000,
                                        showConfirmButton: false
                                    });

                                    // Reload tabel tanpa mereset posisi pagination/scroll
                                    table.ajax.reload(null, false);
                                } else {
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Gagal Menghapus',
                                        text: response.message || 'Terjadi kesalahan saat menghapus data.',
                                        confirmButtonColor: '#dc2626'
                                    });
                                }
                            },
                            error: function(xhr, status, error) {
                                console.error('Error delete:', error);
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Kesalahan Server',
                                    text: 'Gagal menghubungkan ke server. Silakan coba lagi.',
                                    confirmButtonColor: '#dc2626'
                                });
                            }
                        });
                    }
                });
            });

            // ==========================================
            // SELECT2 & FLATPICKR
            // ==========================================
            $('.select2').select2({
                theme: 'bootstrap-5',
                dropdownParent: $('#modalForm'),
                width: '100%'
            });

            const pickerLahir = flatpickr("#tglLahir", {
                locale: 'id',
                dateFormat: 'd F Y',
                maxDate: 'today',
                allowInput: true,
                clickOpens: true,
                disableMobile: true,
                monthSelectorType: 'static',
                yearSelector: true,
                onChange: function(selectedDates) {
                    if (selectedDates.length) {
                        $('#usia').val(Math.max(0, moment().diff(moment(selectedDates[0]), 'years')) + ' Tahun');
                    } else {
                        $('#usia').val('');
                    }
                }
            });

            const pickerDaftar = flatpickr("#tglDaftar", {
                locale: 'id',
                dateFormat: 'd F Y',
                defaultDate: new Date(),
                allowInput: true,
                clickOpens: true,
                disableMobile: true,
                monthSelectorType: 'static'
            });

            $('#iconTglLahir').on('click', function(e) {
                e.preventDefault();
                pickerLahir.open();
            });
            $('#iconTglDaftar').on('click', function(e) {
                e.preventDefault();
                pickerDaftar.open();
            });

            // ==========================================
            // SUBMIT / TAMBAH DATA
            // ==========================================
            $('#btnTambah').click(function() {
                $('#modalTitle').html('<i class="fa-solid fa-file-signature text-primary"></i> Form Pendaftaran Jamaah');
                $('#formPendaftaran')[0].reset();
                $('#idJamaah').val('');
                $('#usia').val('');
                $('.select2').val(null).trigger('change');
                $('#status').val('pending').trigger('change');
                pickerLahir.clear();
                pickerDaftar.setDate(new Date(), true);
                $('#kabupaten').val('');
                $('#id_kabupaten').val('');
                $('#kecamatan').val('').prop('disabled', true).attr('placeholder', 'Pilih Kabupaten dulu...');
                $('#id_kecamatan').val('');
                $('#desa').val('').prop('disabled', true).attr('placeholder', 'Pilih Kecamatan dulu...');
                bootstrap.Modal.getOrCreateInstance(document.getElementById('modalForm')).show();
            });

            $('#formPendaftaran').submit(function(e) {
                e.preventDefault();

                if (!$('#id_kabupaten').val() || !$('#id_kecamatan').val() || !$('#desa').val()) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Wilayah Belum Lengkap',
                        text: 'Harap isi Kabupaten, Kecamatan, dan Desa dengan benar.',
                        confirmButtonColor: '#0a5c43'
                    });
                    return;
                }

                // PERBAIKAN UTAMA: Tambahkan idJamaah di paling atas agar backend tahu ini mode EDIT
                var formData = {
                    idJamaah: $('#idJamaah').val(), // <-- Kunci pembeda Edit / Tambah
                    no_porsi: $('#noPorsi').val(),
                    nama: $('#nama').val(),
                    nik: $('#nik').val(),
                    tempat_lahir: $('#tempatLahir').val(),
                    tgl_lahir: $('#tglLahir').val(),
                    usia: $('#usia').val().replace(' Tahun', ''),
                    jenkel: $('#jenkel').val(),
                    pendidikan: $('#pendidikan').val(),
                    pekerjaan: $('#pekerjaan').val(),
                    telepon: $('#telepon').val(),
                    alamat: $('#alamat').val(),
                    id_kabupaten: $('#id_kabupaten').val(),
                    kabupaten: $('#kabupaten').val(),
                    id_kecamatan: $('#id_kecamatan').val(),
                    kecamatan: $('#kecamatan').val(),
                    desa: $('#desa').val(),
                    tahun: $('#tahun').val(),
                    tgl_daftar: $('#tglDaftar').val(),
                    status: $('#status').val(),
                    bank: $('#bank').val(),
                    no_rek: $('#noRek').val(),
                    no_validasi: $('#noValidasi').val()
                };

                var $btnSubmit = $(this).find('button[type="submit"]');
                var originalBtnText = $btnSubmit.html();
                $btnSubmit.html('<i class="fa-solid fa-spinner fa-spin me-1"></i> Menyimpan...').prop('disabled', true);

                fetch('../api/simpan_pendaftaran.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json'
                        },
                        body: JSON.stringify(formData)
                    })
                    .then(async response => {
                        const text = await response.text();
                        try {
                            return JSON.parse(text);
                        } catch (err) {
                            throw new Error("Server Error: \n\n" + text);
                        }
                    })
                    .then(data => {
                        if (data.status === true) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Berhasil!',
                                text: data.message,
                                confirmButtonColor: '#0a5c43',
                                timer: 2000,
                                showConfirmButton: false
                            });
                            bootstrap.Modal.getOrCreateInstance(document.getElementById('modalForm')).hide();
                            table.ajax.reload(null, false);
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Gagal Menyimpan',
                                text: data.message,
                                confirmButtonColor: '#dc2626'
                            });
                        }
                        $btnSubmit.html(originalBtnText).prop('disabled', false);
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Kesalahan Server',
                            html: `<pre style="text-align:left; font-size:12px;">${error.message}</pre>`,
                            confirmButtonColor: '#dc2626'
                        });
                        $btnSubmit.html(originalBtnText).prop('disabled', false);
                    });
            });
        });
    </script>
</body>

</html>