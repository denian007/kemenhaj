<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<aside class="sidebar" id="sidebar">
    <a href="index.php" class="sidebar-brand">
        <div class="sidebar-brand-logo">
            <img src="../logo.png" alt="Logo" onerror="this.parentElement.innerHTML='<i class=\'fa-solid fa-kaaba\' style=\'color:#063f2e;font-size:24px\'></i>';" />
        </div>
        <div class="sidebar-brand-text">
            <strong>KEMENHAJ</strong>
            <span>Kota Subulussalam</span>
        </div>
    </a>

    <div class="sidebar-user-mobile">
        <div class="avatar-gold"><i class="fa-solid fa-user"></i></div>
        <div class="user-info" style="line-height:1.2;">
            <strong style="display:block; font-size:13px;"><?= $_SESSION['nama_lengkap']; ?></strong>
            <span style="font-size:11px; color:rgba(255,255,255,0.6);"><i class="fa-solid fa-shield"></i> @<?= $_SESSION['username']; ?></span>
        </div>
    </div>

    <ul class="sidebar-menu">
        <li class="menu-label">MENU UTAMA</li>
        <li><a href="index.php" class="<?= $current_page == 'index.php' ? 'active' : '' ?>"><i class="fa-solid fa-chart-line"></i> <span>Dashboard</span></a></li>
        <li><a href="pendaftaran.php" class="<?= $current_page == 'pendaftaran.php' ? 'active' : '' ?>"><i class="fa-solid fa-id-card-clip"></i> <span>Pendaftaran Porsi Haji</span></a></li>
        <li><a href="layanan_umrah.php" class="<?= $current_page == 'layanan_umrah.php' ? 'active' : '' ?>"><i class="fa-solid fa-envelope-open-text"></i> <span>Layanan E-Surat Umrah</span></a></li>
        <li><a href="pengawasan_travel.php" class="<?= $current_page == 'pengawasan_travel.php' ? 'active' : '' ?>"><i class="fa-solid fa-plane-departure"></i> <span>Pengawasan PPII / Travel</span></a></li>

        <li class="menu-label">SISTEM & PENGATURAN</li>
        <li><a href="manajemen_user.php" class="<?= $current_page == 'manajemen_user.php' ? 'active' : '' ?>"><i class="fa-solid fa-users-gear"></i> <span>Manajemen Pengguna</span></a></li>
        <li><a href="pengaturan.php" class="<?= $current_page == 'pengaturan.php' ? 'active' : '' ?>"><i class="fa-solid fa-sliders"></i> <span>Pengaturan Sistem</span></a></li>
    </ul>

    <div class="sidebar-footer">
        <button class="btn-logout-red" id="btnLogout">
            <i class="fa-solid fa-right-from-bracket"></i> Keluar Sistem
        </button>
    </div>
</aside>
<div class="sidebar-overlay" id="sidebarOverlay"></div>